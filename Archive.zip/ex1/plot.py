import pickle
import numpy as np
import matplotlib.pyplot as plt


with open("./log/trainloss_lr_rkl1.txt", "rb") as fp:   # Unpickling
    betta1,costs1,acc1 = pickle.load(fp)
with open("./log/trainloss_lr_rkl2.txt", "rb") as fp:   # Unpickling
    betta2,costs2,acc2 = pickle.load(fp)
with open("./log/trainloss_lr_rkl3.txt", "rb") as fp:   # Unpickling
    betta3,costs3,acc3 = pickle.load(fp)

lr_num1 = [1/i for i in betta1]
lr_num2 = [1/i for i in betta2]
lr_num3 = [1/i for i in betta3]

for i,j in enumerate(costs1): #converting NANs to 1
    if (j!=j):
        costs1[i] = 1
plt.semilogx(lr_num1, costs1)

for i,j in enumerate(costs2):
    if (j!=j):
        costs2[i] = 1
plt.semilogx(lr_num2, costs2)

for i,j in enumerate(costs3):
    if (j!=j):
        costs3[i] = 1
plt.semilogx(lr_num3, costs3)

plt.grid()
plt.xlabel('Initial Learning Rate')
plt.ylabel('Train Loss')
plt.legend(['RKL1', 'RKL2', 'RKL3'], loc='upper left')
plt.savefig("TrainLoss_lr.pdf")
plt.show()


plt.semilogx(lr_num1, acc1)
plt.semilogx(lr_num1, acc2)
plt.semilogx(lr_num1, acc3)
plt.legend(['RKL1', 'RKL2', 'RKL3'], loc='upper left')
plt.grid()
plt.xlabel('Initial Learning Rate')
plt.ylabel('Test Accuracy')
plt.savefig("TestAcc_lr.pdf")
plt.show()



with open("./log/trainloss_epoch_GD.txt", "rb") as fp:   # Unpickling
    betta1,costs1,acc1 = pickle.load(fp)
with open("./log/trainloss_epoch_RKL1.txt", "rb") as fp:   # Unpickling
    betta2,costs2,acc2 = pickle.load(fp)
with open("./log/trainloss_epoch_RKL2.txt", "rb") as fp:   # Unpickling
    betta3,costs3,acc3 = pickle.load(fp)
with open("./log/trainloss_epoch_H2.txt", "rb") as fp:   # Unpickling
    betta4,costs4,acc4 = pickle.load(fp)
with open("./log/trainloss_epoch_KL2.txt", "rb") as fp:   # Unpickling
    betta5,costs5,acc5 = pickle.load(fp)
with open("./log/trainloss_epoch_X2_2.txt", "rb") as fp:   # Unpickling
    betta6,costs6,acc6 = pickle.load(fp)
    
    
plt.plot( acc1)
plt.plot( acc2)
plt.plot( acc3)
plt.plot( acc4)
plt.plot( acc5)
plt.plot( acc6)
plt.legend(['GD', 'RKL1', 'H2', 'KL2', 'X2_2'], loc='upper left')
plt.grid()
plt.xlabel('Epochs')
plt.ylabel('Test Accuracy')
plt.savefig("TestAcc_epoch.pdf")
plt.show()

plt.plot( costs1)
plt.plot( costs2)
plt.plot( costs4)
plt.plot( costs5)
plt.plot( costs6)
plt.legend(['GD', 'RKL1', 'H2', 'KL2', 'X2_2'], loc='upper left')
plt.grid()
plt.xlabel('Epochs')
plt.ylabel('Train loss')
plt.savefig("loss_epoch.pdf")
plt.show()

