
import numpy as np
import matplotlib.pyplot as plt
import pickle
import pdb

# Parameters------------------------------------------------------------------------------------------
prepareData = 0
batchMode = 'batch' # if it is a full_batch, write full_batch, else, it would be batch mode
lr_or_epoch = 'epoch' # choices: 'lr', 'epoch' , if the figure based on learning rate is desired set to 'lr'. if based on epoch, set to 'epoch'.
methodType = 'RKL1' #Choices are :RKL1, RKL2, RKL3, KL1, KL2, H1, H2, X2_1, X2_2, GD

exp_thrshld = 10000
hidden_nodes = 500
epoch_num = 40
batchSize = 128 


# functions------------------------------------------------------------------------------------------
def sigmoid(x):
    x = np.maximum(x,-exp_thrshld)
    return 1 / (1 + np.exp(-x))

def softmax(A):
    A = np.minimum(A,exp_thrshld)
    expA = np.exp(A)
    return expA / expA.sum(axis=1, keepdims=True)

def giveNewBetta(initial_betta, betta, grad, epoch, batch, type = 'RKL2' ):
    INIT_RUNS = 0
    if(initial_betta < 1e1):   #if it is less than 1e1, it will diverge at first tries so let it get closer to the final point then start from the intended point
        INIT_RUNS = 50
    bettaLast = betta.copy()
    if batch + epoch*1000<INIT_RUNS : # move the gradient into a better space!
        betta = (1e2)*np.ones(np.shape(grad))
        bettaLast = betta.copy()
    elif batch+epoch*1000<INIT_RUNS+1:
        betta = (initial_betta)*np.ones(np.shape(grad)) # 1/10e-2
        bettaLast = betta.copy()
    elif type=='RKL1':
        betta = 0.5*(betta+np.sqrt(betta**2+4*(grad**2)))
    elif type=='RKL2':
        betta = (betta**3)/(betta**2 - grad**2)
    elif type=='RKL3':
        if(batch + epoch*1000 == INIT_RUNS+1): # since RKL3 is one step behind RKL2 so we need to pass the first time
            pass
        betta = (betta**3)/(betta**2 - grad**2)
    elif type=='KL1':
        func = lambda bet : (bet**2) * np.log(bet/betta) - (grad**2)
        betta = fsolve(func, betta)
    elif type=='KL2':
        betta = betta * np.exp((grad**2)/(betta**2))
    elif type=='H1':
        func = lambda bet : (bet**2) * (1-np.sqrt(betta/bet)) - (grad**2)
        betta = fsolve(func, betta)
    elif type=='H2':
        betta = (betta**5)/((betta**2-grad**2)**2)
    elif type=='X2_1':
        func = lambda bet : 2*(bet**2) * ((bet/betta)-1) - (grad**2) # the best and fastest one
        betta = fsolve(func, betta)
    elif type=='X2_2':
        betta = betta*(1+(grad**2)/(2*(betta**2)))
    elif type=='GD':
        betta = ((1e1)**(2)) *np.ones(np.shape(grad))

    
    return betta

def prepare_MNIST_pickle():

    image_size = 28 # width and length
    no_of_different_labels = 10 #  i.e. 0, 1, 2, 3, ..., 9
    image_pixels = image_size * image_size
    train_data = np.loadtxt("mnist_train.csv", delimiter=",")
    test_data = np.loadtxt("mnist_test.csv", delimiter=",") 
    
    fac = 255  *0.99 + 0.01
    train_imgs = np.asfarray(train_data[:, 1:]) / fac
    test_imgs = np.asfarray(test_data[:, 1:]) / fac
    train_labels = np.asfarray(train_data[:, :1])
    test_labels = np.asfarray(test_data[:, :1])
    
    lr = np.arange(10)
    for label in range(10):
        one_hot = (lr==label).astype(np.int)
        print("label: ", label, " in one-hot representation: ", one_hot)
    
    
    lr = np.arange(no_of_different_labels)
    # transform labels into one hot representation
    train_labels_one_hot = (lr==train_labels).astype(np.float)
    test_labels_one_hot = (lr==test_labels).astype(np.float)
    # we don't want zeroes and ones in the labels neither:
    train_labels_one_hot[train_labels_one_hot==0] = 0.01
    train_labels_one_hot[train_labels_one_hot==1] = 0.99
    test_labels_one_hot[test_labels_one_hot==0] = 0.01
    test_labels_one_hot[test_labels_one_hot==1] = 0.99
    
    
    for i in range(10):
        img = train_imgs[i].reshape((28,28))
        plt.imshow(img, cmap="Greys")
        plt.show()
    
    import pickle
    with open("pickled_mnist.pkl", "bw") as fh:
        data = (train_imgs, 
                test_imgs, 
                train_labels,
                test_labels,
                train_labels_one_hot,
                test_labels_one_hot)
        pickle.dump(data, fh)


# Main code-------------------------------------------------------------------------------

if(prepareData):
    prepare_MNIST_pickle()

# Loading MNIST data
with open("pickled_mnist.pkl", "br") as fh:
    data = pickle.load(fh)
train_imgs = data[0]
test_imgs = data[1]
train_labels = data[2]
test_labels = data[3]
train_labels_one_hot = data[4]
test_labels_one_hot = data[5]
image_size = 28 # width and length
no_of_different_labels = 10 #  i.e. 0, 1, 2, 3, ..., 9
image_pixels = image_size * image_size

classes = 10
MnistData = train_imgs
labels = train_labels
samples = MnistData.shape[0] # 1500 samples
features = MnistData.shape[1] # 2 features
finalCost = []
finalTestAcc = []
costs = []
testAcc = []
# generate the one-hot-encodings
OnehotLabels = np.zeros((samples, classes))
for i in range(samples):
    OnehotLabels[i, int(labels[i])] = 1
	
if(lr_or_epoch is 'lr'):
    init_betta = [1e4, 1e3, 1e2, 1e1, 1e0, 1e-1]
else:
    init_betta = [1e2]

for initial_betta in init_betta: 

    # randomly initialize weights
    W1 = np.random.randn(features, hidden_nodes)
    b1 = np.random.randn(hidden_nodes)
    W2 = np.random.randn(hidden_nodes, classes)
    b2 = np.random.randn(classes)
    
    alphaW2 = np.ones((hidden_nodes, classes))
    alphaW1 = np.ones((features, hidden_nodes))
    alphab2 = np.ones(classes,)
    alphab1 = np.ones(hidden_nodes,)
    if(batchMode == 'full_batch'):
        batchSize = samples
    batchNum = (samples//batchSize)
    for epoch in range(epoch_num):
        randomize = np.arange(samples)
        np.random.shuffle(randomize)
        MnistData = MnistData[randomize,:]
        OnehotLabels= OnehotLabels[randomize]
        for batch in range(batchNum):
            X = MnistData[batch*batchSize: min((batch+1)*batchSize,samples),:]
            T = OnehotLabels[batch*batchSize: min((batch+1)*batchSize,samples)]
            # forward pass
            A = sigmoid(X.dot(W1) + b1) # A = sigma(Z)
            Y = softmax(A.dot(W2) + b2) # Y = softmax(Z2)
            # backward pass
            delta2 = Y - T
            delta1 = (delta2).dot(W2.T) * A * (1 - A)
    
            # gradient w by descent update
            gradW2 = A.T.dot(delta2) + 1e-4*W2/np.shape(X)[0]
            alphaW2 = giveNewBetta(initial_betta, alphaW2, gradW2, epoch,batch, methodType)
    
            gradb2 = (delta2).sum(axis=0) 
            alphab2 = giveNewBetta(initial_betta, alphab2, gradb2, epoch,batch, methodType)
            gradW1 = X.T.dot(delta1) + 1e-4*W1/np.shape(X)[0]
            alphaW1 = giveNewBetta(initial_betta, alphaW1, gradW1, epoch,batch, methodType)
            gradb1 = (delta1).sum(axis=0) 
            alphab1 = giveNewBetta(initial_betta, alphab1, gradb1, epoch,batch, methodType)
                
            W2 -= (1/alphaW2) * gradW2
            b2 -= (1/alphab2) * gradb2
    
            W1 -= (1/alphaW1) * gradW1
            b1 -= (1/alphab1) * gradb1
                
        # save loss function values across training iterations
        A = sigmoid(MnistData.dot(W1) + b1) # A = sigma(Z)
        Y = softmax(A.dot(W2) + b2)
        #print(Y)
        if epoch % 1 == 0: 
    
            tmp = A.dot(W2) + b2
            logY = tmp - np.log((np.exp(tmp)).sum(axis=1, keepdims=True))
            loss = np.sum(-OnehotLabels * logY)/samples + 1e-4*0.5*(1/samples)*(np.sum(W1**2) + np.sum(W2**2))
            print('epoch({bi}/{ti}): loss={l}'.format(bi=epoch, ti=epoch_num, l=loss))
            costs.append(loss)
            A = sigmoid(test_imgs.dot(W1) + b1) # A = sigma(Z)
            Y = softmax(A.dot(W2) + b2) # Y = softmax(Z2)
            corr = (test_labels == np.argmax(Y,1).reshape(-1,1))
            acc = (sum(corr)/np.shape(corr)[0])*100
            testAcc.append(acc)
			
	#test accuracy
    corr = (test_labels == np.argmax(Y,1).reshape(-1,1))
    finalTestAcc.append(acc)
    finalCost.append(loss)
if(lr_or_epoch is 'lr'):
    if(batchMode == 'full_batch'):
        with open("./log/trainloss_lr_fullBatch_" + methodType +".txt", "wb") as fp:   #Pickling
            pickle.dump([init_betta, finalCost, finalTestAcc], fp)
    else:
        with open("./log/trainloss_lr_" + methodType +".txt", "wb") as fp:   #Pickling
            pickle.dump([init_betta, finalCost, finalTestAcc], fp)
else:
    if(batchMode == 'full_batch'):
        with open("./log/trainloss_epoch_fullBatch_" + methodType +".txt", "wb") as fp:   #Pickling
            pickle.dump([epoch_num, costs, testAcc], fp)
    else:
        with open("./log/trainloss_epoch_" + methodType +".txt", "wb") as fp:   #Pickling
            pickle.dump([epoch_num, costs, testAcc], fp)



