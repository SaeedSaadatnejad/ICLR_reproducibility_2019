## Readme
Running the code is pretty easy.
1- First download the MNIST datset from # https://www.python-course.eu/neural_network_mnist.php and put it in the same folder as the code
2- set the variable "prepareData" which is in the first lines of the code to 1 . This will do the preprocessings over the data.
3- After running once, you can set the "prepareData" zero. To have each of the settings, choose each choice by setting parameters from the first part of the code.
    The choices are : 
	   - Full_batch or batch
	   - loop over learning rates or epochs
	   - and between different methods like SGD, RKL1,..
Each time the code runs, it will write on of the data files which can be plotted using the plot file. whenever the plot file is excecuted, all the data files are read and the figures are generated and saved.
 