Team: Sharks
This is the description of the experiment 3 of the project:

This folder consists of three parts:
1) data: the dataset of cifar10. You should download it from https://www.cs.toronto.edu/~kriz/cifar.html and put it there.
2) out:
	the outputs of losses and accuracies (using pal) during training
3) root:
	1- main.py: runs the functions for training and testing with the new learning rate algorithm
	2- vgg.py: defines the architecture of VGG totally that we used VGG-16
	3- plot.py: running this file, plot the curves out of results stored in 'outs' folder
	4- main_initBetta.py: in order to plot the curves related to initial learning rate you can run this file.
Requirements: torch (CUDA version), torch vision 

In order to run this code, you need to run 'main.py' which first reads the input data, normalizes the data (with default norm vector of Image Net), prepares it in the correct form and trains vggnet16 (this version is running with 'RKL1' function as the updating algorithm but you can test it with other functions as you want). Finally it evaluates those algorithms on the test set and the results are printed. The outputs are stored in the 'outs' folder that can be used for plotting.

* Don't forget to put data into the appropriate folder