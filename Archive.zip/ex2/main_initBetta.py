import os
import time

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
import torch.utils.data
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import vgg
import pickle as pkl
import pdb
from scipy.optimize import fsolve


best_prec1 = 0
INIT_LR = 1000
INIT_RUNS = 5
EPOCH_NUM = 100
BATCH_SIZE = 128
out_path = 'outs/'
print_freq = 20
WEIGHT_DECAY = 1e-4
LRfunc = 'X2_2'


def main():
    global best_prec1

    # Check the save_dir exists or not
    if not os.path.exists(out_path):
        os.makedirs(out_path)

    trainLoss_total =[]
    testAcc_total = []
    for initBetta in [1e4, 1e3, 1e2, 1e1, 1e0, 1e-1]:
        model = vgg.__dict__['vgg16_bn']()

        model.features = torch.nn.DataParallel(model.features)
        model.cuda()

        cudnn.benchmark = True

        # first of all, normalization
        normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                         std=[0.229, 0.224, 0.225])

        # transforms and normalization used by dataloader
        train_loader = torch.utils.data.DataLoader(
            datasets.CIFAR10(root='./data', train=True, transform=transforms.Compose([
                transforms.RandomHorizontalFlip(),
                transforms.RandomCrop(32, 4),
                transforms.ToTensor(),
                normalize,
            ]), download=True),
            batch_size=BATCH_SIZE, shuffle=True,
            num_workers=4, pin_memory=True)

        val_loader = torch.utils.data.DataLoader(
            datasets.CIFAR10(root='./data', train=False, transform=transforms.Compose([
                transforms.ToTensor(),
                normalize,
            ])),
            batch_size=BATCH_SIZE, shuffle=False,
            num_workers=4, pin_memory=True)

        # define loss function (criterion) and pptimizer
        criterion = nn.CrossEntropyLoss().cuda()

        # define the new learning rate for all parameters of the model
        lr = {}
        for name, param in model.named_parameters():
            if param.requires_grad:
                lr[name]=INIT_LR
        # training loop
        iteration = 0
        test_accs = []
        train_losses = []
        for epoch in range(EPOCH_NUM):

            # train for one epoch
            iteration, lr, train_loss = train(train_loader, model, criterion, epoch, iteration, lr, WEIGHT_DECAY, LRfunc, initBetta)

            # evaluate on validation set
            prec1 = validate(val_loader, model, criterion)
            test_accs.append(prec1.cpu().numpy().tolist())
            train_losses.append(train_loss.avg.cpu().numpy().tolist())

            # remember best prec@1
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)

        trainLoss_total.append(train_losses[-1])
        testAcc_total.append(test_accs[-1])

    with open(out_path+'trainLoss_lr_' + LRfunc + '.txt', "wb") as fp:   #Pickling
        pkl.dump(trainLoss_total, fp)
    with open(out_path+'testAcc_lr_' + LRfunc + '.txt', "wb") as fp:   #Pickling
        pkl.dump(testAcc_total, fp)

    return

def giveNewBetta(betta, grad, iteration, type='RKL1', initBetta=10.0):
    bettaLast = betta

    if iteration<INIT_RUNS : # move the gradient into a better space!
        betta = torch.tensor(10.0).expand_as(grad).cuda()
    elif iteration<INIT_RUNS+1:
        betta = torch.tensor(initBetta).expand_as(grad).cuda() # 1/10e-2
    
    elif type=='SGD':
        bettaLast = betta
    elif type=='RKL1':
        bettaLast = betta
        betta = 0.5*(betta+torch.sqrt(betta**2+4*(grad**2)))
    elif type=='RKL2':
        bettaLast = betta
        betta = (betta**3)/(betta**2 - grad**2)
    elif type=='KL1':
        bettaLast = betta
        func = lambda bet : (bet**2) * torch.log(torch.tensor(bet)/betta) - (grad**2)
        betta = fsolve(func, betta)
    elif type=='KL2':
        bettaLast = betta
        betta = betta * torch.exp((grad**2)/(betta**2))
    elif type=='H1':
        pdb.set_trace()
        bettaLast = betta
        func = lambda bet : (bet**2) * (1-torch.sqrt(betta/torch.tensor(bet))) - (grad**2)
        betta = fsolve(func, betta)
    elif type=='H2':
        bettaLast = betta
        betta = (betta**5)/((betta**2-grad**2)**2)
    elif type=='X2_1':
        bettaLast = betta
        func = lambda bet : 2*(bet**2) * ((bet/betta)-1) - (grad**2) # the best and fastest one
        betta = fsolve(func, betta)
    elif type=='X2_2':
        bettaLast = betta
        betta = betta*(1+(grad**2)/(2*(betta**2)))

    # clipping
    if iteration>INIT_RUNS:
        betta = torch.min(torch.max(betta, bettaLast), 2*bettaLast)
    
    return betta

def train(train_loader, model, criterion, epoch, iteration, lr, weight_decay, learningRateFunc, initBetta=10.0):
    """
        Run one train epoch
    """
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()

    # switch to train mode
    model.train()

    end = time.time()
    #lr = lr * (0.5 ** (epoch // 30))
    for i, (input, target) in enumerate(train_loader):

        # measure data loading time
        data_time.update(time.time() - end)

        target = target.cuda(async=True)
        input_var = torch.autograd.Variable(input).cuda()
        target_var = torch.autograd.Variable(target)

        # compute output
        output = model(input_var)
        loss = criterion(output, target_var)

        # backprop loss to compute gradient and do one SGD step
        loss.backward()
        # find new betta and one step of optimization
        with torch.no_grad():
            for name, param in model.named_parameters():
                if param.requires_grad:
                    lr_this=lr[name]
                    g=param.grad
                    lr_this=giveNewBetta(lr_this, g, iteration, learningRateFunc, initBetta)
                    lr[name]=lr_this
                    #print name, param.grad.shape
                    param -= (g + weight_decay*param)/lr_this
                    # Manually zero the gradients after running the backward pass
                    param.grad.zero_()

        output = output.float()
        loss = loss.float()
        # measure accuracy and record loss
        prec1 = accuracy(output.data, target)[0]
        losses.update(loss.data[0], input.size(0))
        top1.update(prec1[0], input.size(0))

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        if i % print_freq == 0:
            #print('betta:', torch.mean(lr))
            print('Epoch: [{0}][{1}/{2}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                  'Prec@1 {top1.val:.3f} ({top1.avg:.3f})'.format(
                      epoch, i, len(train_loader), batch_time=batch_time,
                      data_time=data_time, loss=losses, top1=top1))

        iteration+=1

    return iteration, lr, losses


def validate(val_loader, model, criterion):
    """
    Run evaluation
    """
    batch_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()

    # switch to evaluate mode
    model.eval()

    end = time.time()
    for i, (input, target) in enumerate(val_loader):
        target = target.cuda(async=True)
        input_var = torch.autograd.Variable(input, volatile=True).cuda()
        target_var = torch.autograd.Variable(target, volatile=True)

        # compute output
        output = model(input_var)
        loss = criterion(output, target_var)

        output = output.float()
        loss = loss.float()

        # measure accuracy and record loss
        prec1 = accuracy(output.data, target)[0]
        losses.update(loss.data[0], input.size(0))
        top1.update(prec1[0], input.size(0))

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        if i % print_freq == 0:
            print('Test: [{0}/{1}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                  'Prec@1 {top1.val:.3f} ({top1.avg:.3f})'.format(
                      i, len(val_loader), batch_time=batch_time, loss=losses,
                      top1=top1))

    print(' * Prec@1 {top1.avg:.3f}'
          .format(top1=top1))

    return top1.avg

class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def accuracy(output, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    maxk = max(topk)
    batch_size = target.size(0)

    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))

    res = []
    for k in topk:
        correct_k = correct[:k].view(-1).float().sum(0)
        res.append(correct_k.mul_(100.0 / batch_size))
    return res


if __name__ == '__main__':
    main()
