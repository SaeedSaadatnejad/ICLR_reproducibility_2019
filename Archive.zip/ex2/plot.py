import matplotlib.pyplot as plt
import pickle as pkl
import numpy as np

out_path = 'outs/'

with open(out_path+'testAcc_epoch_RKL2.txt', "rb") as fp:   # Unpickling
    rkl2 = pkl.load(fp)
with open(out_path+'testAcc_epoch_SGD.txt', "rb") as fp:   # Unpickling
    sgd = pkl.load(fp)
with open(out_path+'testAcc_epoch_X2_2.txt', "rb") as fp:   # Unpickling
    x22 = pkl.load(fp)
with open(out_path+'testAcc_epoch_H2.txt', "rb") as fp:   # Unpickling
    h2 = pkl.load(fp)
  
plt.plot(rkl2)
plt.plot(sgd)
plt.plot(x22)
plt.plot(h2)
plt.legend(['RKL', 'SGD', 'X2', 'H'], loc='lower right')
plt.grid()
plt.xlabel('Epochs')
plt.ylabel('test accuracy')
plt.savefig(out_path + "testAcc_epoch.png")
plt.show()


with open(out_path+'trainLoss_epoch_RKL2.txt', "rb") as fp:   # Unpickling
    rkl2 = pkl.load(fp)
with open(out_path+'trainLoss_epoch_SGD.txt', "rb") as fp:   # Unpickling
    sgd = pkl.load(fp)
with open(out_path+'trainLoss_epoch_X2_2.txt', "rb") as fp:   # Unpickling
    x22 = pkl.load(fp)
with open(out_path+'trainLoss_epoch_H2.txt', "rb") as fp:   # Unpickling
    h2 = pkl.load(fp)

plt.plot(rkl2)
plt.plot(sgd)
plt.plot(x22)
plt.plot(h2)
plt.legend(['RKL', 'SGD', 'X2', 'H'], loc='upper right')
plt.grid()
plt.xlabel('Epochs')
plt.ylabel('train loss')
plt.savefig(out_path + "trainLoss_epoch.png")
plt.show()