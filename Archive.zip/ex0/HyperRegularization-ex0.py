# Import functions
import numpy as np
from scipy.optimize import fsolve
from costs import *
import datetime
from helpers import *
import pickle as pkl
import pdb


# some constants
INIT_RUNS = 0
INITIAL_LEARNING_RATE = 0.1
INITIAL_LEARNING_RATE_ALG = 0.01
out_path = 'outs/'

def giveNewBetta(betta, grad, iteration, type='RKL1'):
    bettaLast = betta

    if iteration<INIT_RUNS : # move the gradient into a better space!
        betta = (1/INITIAL_LEARNING_RATE) *np.ones(np.shape(grad))
    elif iteration<INIT_RUNS+1:
        betta = (1/INITIAL_LEARNING_RATE_ALG)*np.ones(np.shape(grad))
    
    elif type=='RKL1':
        bettaLast = betta
        betta = 0.5*(betta+np.sqrt(betta**2+4*(grad**2)))
    elif type=='RKL2':
        bettaLast = betta
        betta = (betta**3)/(betta**2 - grad**2)
    elif type=='KL1':
        bettaLast = betta
        func = lambda bet : (bet**2) * np.log(bet/betta) - (grad**2)
        betta = fsolve(func, betta)
    elif type=='KL2':
        bettaLast = betta
        betta = betta * np.exp((grad**2)/(betta**2))
    elif type=='H1':
        bettaLast = betta
        func = lambda bet : (bet**2) * (1-np.sqrt(betta/bet)) - (grad**2)
        betta = fsolve(func, betta)
    elif type=='H2':
        bettaLast = betta
        betta = (betta**5)/((betta**2-grad**2)**2)
    elif type=='X2_1':
        bettaLast = betta
        func = lambda bet : 2*(bet**2) * ((bet/betta)-1) - (grad**2) # the best and fastest one
        betta = fsolve(func, betta)
    elif type=='X2_2':
        bettaLast = betta
        betta = betta*(1+(grad**2)/(2*(betta**2)))

    # clipping
    if iteration>INIT_RUNS:
        betta = np.minimum(np.maximum(betta, bettaLast), 2*bettaLast)

    return betta


# # Gradient Descent with new Learning Rate Algorithm

def compute_gradient(y, tx, w):
    """Compute the gradient."""
    err = y - tx.dot(w)
    grad = -tx.T.dot(err) / len(err)
    return grad, err

def gradient_descent_newLR(y, tx, initial_w, max_iters, betta):
    ws = [initial_w]
    losses = []
    w = initial_w
    for n_iter in range(max_iters):
        # compute loss, gradient
        grad, err = compute_gradient(y, tx, w)
        loss = calculate_mse(err)
        
        # calc betta
        betta = giveNewBetta(betta, grad, n_iter, type='H1')
        
        # gradient w by descent update
        w = w - grad/betta
        
        # store w and loss
        ws.append(w)
        losses.append(loss)
        #print("Gradient Descent newLR({bi}/{ti}): loss={l}, w0={w0}, w1={w1}".format(
        #      bi=n_iter, ti=max_iters - 1, l=loss, w0=w[0], w1=w[1]))

    return losses, ws


# # Original Gradient Descent
def gradient_descent(y, tx, initial_w, max_iters, gamma):
    """Gradient descent algorithm."""
    # Define parameters to store w and loss
    ws = [initial_w]
    losses = []
    w = initial_w
    for n_iter in range(max_iters):
        # compute loss, gradient
        grad, err = compute_gradient(y, tx, w)
        loss = calculate_mse(err)
        # gradient w by descent update
        w = w - gamma * grad
        # store w and loss
        ws.append(w)
        losses.append(loss)
        #print("Gradient Descent({bi}/{ti}): loss={l}, w0={w0}, w1={w1}".format(
        #      bi=n_iter, ti=max_iters - 1, l=loss, w0=w[0], w1=w[1]))

    return losses, ws

def compute_stoch_gradient(y, tx, w):
    """Compute a stochastic gradient from just few examples n and their corresponding y_n labels."""
    err = y - tx.dot(w)
    grad = -tx.T.dot(err) / len(err)
    return grad, err

def stochastic_gradient_descent_newLR(
        y, tx, initial_w, batch_size, max_iters, betta):
    """Stochastic gradient descent."""
    # Define parameters to store w and loss
    ws = [initial_w]
    losses = []
    w = initial_w
    
    iteration=0
    for n_iter in range(max_iters):
        for y_batch, tx_batch in batch_iter(y, tx, batch_size=batch_size, num_batches=1):
            # compute a stochastic gradient and loss
            grad, _ = compute_stoch_gradient(y_batch, tx_batch, w)
            # calc betta
            betta = giveNewBetta(betta, grad, iteration, type='H1')
            # update w through the stochastic gradient update
            w = w - (1/betta) * grad
            # calculate loss
            loss = compute_loss(y, tx, w)
            # store w and loss
            ws.append(w)
            losses.append(loss)
            iteration+=1

        #print("SGD new LR({bi}/{ti}): loss={l}, w0={w0}, w1={w1}".format(
        #      bi=n_iter, ti=max_iters - 1, l=loss, w0=w[0], w1=w[1]))
    return losses, ws

# # Original Stochastic Gradient Descent
def stochastic_gradient_descent(
        y, tx, initial_w, batch_size, max_iters, gamma):
    """Stochastic gradient descent."""
    # Define parameters to store w and loss
    ws = [initial_w]
    losses = []
    w = initial_w
    
    for n_iter in range(max_iters):
        for y_batch, tx_batch in batch_iter(y, tx, batch_size=batch_size, num_batches=1):
            # compute a stochastic gradient and loss
            grad, _ = compute_stoch_gradient(y_batch, tx_batch, w)
            # update w through the stochastic gradient update
            w = w - gamma * grad
            # calculate loss
            loss = compute_loss(y, tx, w)
            # store w and loss
            ws.append(w)
            losses.append(loss)

        #print("SGD({bi}/{ti}): loss={l}, w0={w0}, w1={w1}".format(
        #      bi=n_iter, ti=max_iters - 1, l=loss, w0=w[0], w1=w[1]))
    return losses, ws


def main():
    # Load the data
    height, weight, gender = load_data(sub_sample=False, add_outlier=False)
    x, mean_x, std_x = standardize(height)
    y, tx = build_model_data(x, weight)

    # gradient descent + new learning rate
    # Define the parameters of the algorithm.
    max_iters = 10000
    betta = 100*np.ones(np.shape(tx)[1],)

    # Initialization
    w_initial = np.array([0, 0])

    # Start gradient descent.
    start_time = datetime.datetime.now()
    gradient_losses, gradient_ws = gradient_descent_newLR(y, tx, w_initial, max_iters, betta)
    end_time = datetime.datetime.now()

    # Print result
    exection_time = (end_time - start_time).total_seconds()
    print("Gradient Descent new LR: execution time per iteration={t:.2f} micro seconds".format(t=1000000*exection_time/max_iters))
    w0=[l.tolist()[0] for l in gradient_ws]
    w1=[l.tolist()[1] for l in gradient_ws]
    with open(out_path+'GD_newLR_w0.txt', "wb") as fp:   #Pickling
        pkl.dump(w0, fp)
    with open(out_path+'GD_newLR_w1.txt', "wb") as fp:   #Pickling
        pkl.dump(w1, fp)


    # gradient descent original
    # Define the parameters of the algorithm.
    max_iters = 10000
    gamma = 0.7

    # Initialization
    w_initial = np.array([0, 0])

    # Start gradient descent.
    start_time = datetime.datetime.now()
    gradient_losses, gradient_ws = gradient_descent(y, tx, w_initial, max_iters, gamma)
    end_time = datetime.datetime.now()

    # Print result
    exection_time = (end_time - start_time).total_seconds()
    print("Gradient Descent: execution time per iteration={t:.2f} micro seconds".format(t=1000000*exection_time/max_iters))
    w0=[l.tolist()[0] for l in gradient_ws]
    w1=[l.tolist()[1] for l in gradient_ws]
    with open(out_path+'GD_orig_w0.txt', "wb") as fp:   #Pickling
        pkl.dump(w0, fp)
    with open(out_path+'GD_orig_w1.txt', "wb") as fp:   #Pickling
        pkl.dump(w1, fp)

    # stochastic gradient descent + new learning rate
    # Define the parameters of the algorithm.
    max_iters = 10000
    betta = 0.1
    batch_size = 1

    # Initialization
    w_initial = np.array([0, 0])

    # Start SGD.
    start_time = datetime.datetime.now()
    sgd_losses, sgd_ws = stochastic_gradient_descent_newLR(
        y, tx, w_initial, batch_size, max_iters, betta)

    end_time = datetime.datetime.now()

    # Print result
    exection_time = (end_time - start_time).total_seconds()
    print("SGD new LR: execution time per iteration={t:.2f} micro seconds".format(t=1000000*exection_time/max_iters))
    w0=[l.tolist()[0] for l in sgd_ws]
    w1=[l.tolist()[1] for l in sgd_ws]
    with open(out_path+'SGD_newLR_w0.txt', "wb") as fp:   #Pickling
        pkl.dump(w0, fp)
    with open(out_path+'SGD_newLR_w1.txt', "wb") as fp:   #Pickling
        pkl.dump(w1, fp)


    # stochastic gradient descent original
    # Define the parameters of the algorithm.
    max_iters = 10000
    gamma = 0.7
    batch_size = 1

    # Initialization
    w_initial = np.array([0, 0])

    # Start SGD.
    start_time = datetime.datetime.now()
    sgd_losses, sgd_ws = stochastic_gradient_descent(
        y, tx, w_initial, batch_size, max_iters, gamma)

    end_time = datetime.datetime.now()

    # Print result
    exection_time = (end_time - start_time).total_seconds()
    print("SGD: execution time per iteration={t:.2f} micro seconds".format(t=1000000*exection_time/max_iters))
    w0=[l.tolist()[0] for l in sgd_ws]
    w1=[l.tolist()[1] for l in sgd_ws]
    with open(out_path+'SGD_orig_w0.txt', "wb") as fp:   #Pickling
        pkl.dump(w0, fp)
    with open(out_path+'SGD_orig_w1.txt', "wb") as fp:   #Pickling
        pkl.dump(w1, fp)


if __name__ == '__main__':
    main()