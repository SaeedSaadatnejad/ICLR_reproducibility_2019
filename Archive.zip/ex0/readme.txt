Team: Sharks
This is the description of the experiment 0 of the project:

This folder consists of three parts:
1) data:
The csv data file which is borrowed from the HW assignments
2) outs:
The outputs can be used for plotting of different algorithms implemented there
3) root:
	a) HyperRegularization-ex0.py: The main code which should be executed
	b) costs.py: cost functions which are used by the main code
	c) helpers.py: helper file for loading data borrowed from HW assignments
	d) plot.py: running this file, plot the curves out of results stored in 'outs' folder

In order to run this code, you need to run 'main.py' which first reads the input data, prepares it in the correct format and runs GD and SGD with new and original learning rates. The results are also stored in the 'outs' folder that can be used for plotting.