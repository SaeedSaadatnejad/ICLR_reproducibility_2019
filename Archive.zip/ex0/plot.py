import matplotlib.pyplot as plt
import pickle as pkl
import numpy as np

out_path = 'outs/'

with open(out_path+'GD_orig_w0.txt', "rb") as fp:   # Unpickling
    w0_GD_orig = pkl.load(fp)
with open(out_path+'GD_orig_w1.txt', "rb") as fp:   # Unpickling
    w1_GD_orig = pkl.load(fp)
with open(out_path+'GD_newLR_w0.txt', "rb") as fp:   # Unpickling
    w0_GD_newLR = pkl.load(fp)
with open(out_path+'GD_newLR_w1.txt', "rb") as fp:   # Unpickling
    w1_GD_newLR = pkl.load(fp)

  
plt.plot(w0_GD_orig)
plt.plot(w0_GD_newLR)
plt.legend(['GD_orig', 'GD_newLR'], loc='upper left')
plt.grid()
plt.xlabel('Epochs')
plt.ylabel('w0')
plt.savefig(out_path + "w0_GD.png")
plt.show()


plt.plot(w1_GD_orig)
plt.plot(w1_GD_newLR)
plt.legend(['GD_orig', 'GD_newLR'], loc='upper left')
plt.grid()
plt.xlabel('Epochs')
plt.ylabel('w1')
plt.savefig(out_path + "w1_GD.png")
plt.show()